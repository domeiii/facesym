<?php

define("DB_DRIVER", "mysql");
define ("DB_NAME", "facesym");
define ("DB_HOST", "localhost");
define("DB_USER", "facesym");
define ("DB_PWD", "vhzbYHE6#3F");

?>