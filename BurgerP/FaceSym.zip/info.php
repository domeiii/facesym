<?PHP
phpinfo();
?>