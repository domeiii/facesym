<?php
session_start();
$pdo = new PDO('mysql:host=localhost;dbname=images', 'root', '');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Registrierung</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link rel="stylesheet" href="build/css/countrySelect.css">

</head>
<body>

<?php
$showFormular = true; //Variable ob das Registrierungsformular anezeigt werden soll

if(isset($_GET['register'])) {
    $error = false;
    $username = $_POST['username'];
    $email = $_POST['email'];
    $passwort = $_POST['passwort'];
    $passwort2 = $_POST['passwort2'];
    $country = $_POST['country'];
    $sex = $_POST['sex'];
    $date = $_POST['date'];


    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo 'Bitte eine gültige E-Mail-Adresse eingeben<br>';
        $error = true;
    }
    if(strlen($passwort) == 0) {
        echo 'Bitte ein Passwort angeben<br>';
        $error = true;
    }
    if($passwort != $passwort2) {
        echo 'Die Passwörter müssen übereinstimmen<br>';
        $error = true;
    }

    //Überprüfe, dass die E-Mail-Adresse noch nicht registriert wurde
    if(!$error) {
        $statement = $pdo->prepare("SELECT * FROM users WHERE email = :email");
        $result = $statement->execute(array('email' => $email));
        $user = $statement->fetch();

        if($user !== false) {
            echo 'Diese E-Mail-Adresse ist bereits vergeben<br>';
            $error = true;
        }
    }

    //Überprüft ob der Benutzername schon vorhanden ist
    if(!$error) {
        $statement = $pdo->prepare("SELECT * FROM users WHERE username = :username");
        $result = $statement->execute(array('username' => $username));
        $user = $statement->fetch();

        if (strlen($username) == 0) {
            echo 'Bitte einen Usernamen angeben <br>';
            $error = true;
        }
        if ($user !== false) {
            echo 'Benutzername ist zu lang oder existiert bereits <br>';
            $error = true;
        }
    if (!$error) {
        if ($sex !== "male" && $sex !== "female") {
            echo 'Please choose a sex <br>';
            $error = true;
        }
    }
    if (!$error) {
        if ($date == 0) {
            echo 'Insert your birthdate';
            $error = true;
        }
    }

    }

    //Keine Fehler, wir können den Nutzer registrieren
    if(!$error) {
        $passwort_hash = password_hash($passwort, PASSWORD_DEFAULT);

        $statement = $pdo->prepare("INSERT INTO users (username, email, passwort, country, sex, date) VALUES (:username, :email, :passwort, :country, :sex, :date )");
        $result = $statement->execute(array('username' => $username, 'email' => $email, 'passwort' => $passwort_hash, 'country' => $country, 'sex' => $sex, 'date' => $date));

        if($result) {
            echo 'Du wurdest erfolgreich registriert. <a href="login.php">Zum Login</a>';
            $showFormular = false;
        } else {
            echo 'Beim Abspeichern ist leider ein Fehler aufgetreten<br>';
        }
    }
}

if($showFormular) {
    ?>

    <form action="?register=1" method="post">

        <label for="username">Username:</label>
        <input type="text" size=" 34" max="250" name="username"><br><br>

        <label for="email">E-Mail:</label>
        <input type="email" size="40" maxlength="250" name="email"><br><br>

        <label for="password">Password:</label>
        <input type="password" size="40"  maxlength="250" name="passwort"><br>

        <label for="password2">Repeat Password:</label>
        <input type="password" size="40" maxlength="250" name="passwort2"><br><br>

        <label for="country">Country:</label>
        <input type="text" size="34" maxlength="200" id="country" name = "country"/>
        <input type="hidden" id="country_code" />

        <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
        <script src="build/js/countrySelect.min.js"></script>
        <script>
            $("#country").countrySelect();
        </script>
        <br><br>

        <label for="sex">Sex:</label>
        <select name="sex">
            <option value="">Choose your sex</option>
            <option value="female">Female</option>
            <option value="male">Male</option>
        </select>
        <br><br>


        <div class="form-group">
            <!--  jQuery -->
            <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.3.min.js"></script>

            <!-- Isolated Version of Bootstrap, not needed if your site already uses Bootstrap -->
            <link rel="stylesheet" href="https://formden.com/static/cdn/bootstrap-iso.css" />

            <!-- Bootstrap Date-Picker Plugin -->
            <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/js/bootstrap-datepicker.min.js"></script>
            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.4.1/css/bootstrap-datepicker3.css"/>
            <script>
                $(document).ready(function(){
                    var date_input=$('input[name="date"]'); //our date input has the name "date"
                    var container=$('.bootstrap-iso form').length>0 ? $('.bootstrap-iso form').parent() : "body";
                    var options={
                        format: 'mm/dd/yyyy',
                        container: container,
                        todayHighlight: true,
                        autoclose: true,
                    };
                    date_input.datepicker(options);
                })
            </script>
            <label for="date" class="conrol-label">Date</label>
            <input class="form-control" id="date" name="date" placeholder="DD/MM/YYY" type="text"
        </div>

        <input type="submit" value="Abschicken">
    </form>


    <?php
} //Ende von if($showFormular)
?>

</body>
</html>