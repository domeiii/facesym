<?php
session_start();
$pdo = new PDO('mysql:host=localhost;dbname=facesymtest', 'root', '');
$con=mysqli_connect("localhost","root","","facesymtest");

    $error = false;
    $username = $_POST['username'];
    $email = $_POST['email'];
    $passwort = $_POST['passwort'];
    $passwort2 = $_POST['passwort2'];
    $country = $_POST['country'];
    $sex = $_POST['sex'];
    $date = $_POST['date'];
    echo $username;
    echo $email;


    if(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo 'Bitte eine gültige E-Mail-Adresse eingeben<br>';
        $error = true;
    }
    if(strlen($passwort) == 0) {
        echo 'Bitte ein Passwort angeben<br>';
        $error = true;
    }
    if($passwort != $passwort2) {
        echo 'Die Passwörter müssen übereinstimmen<br>';
        $error = true;
    }

    //Überprüfe, dass die E-Mail-Adresse noch nicht registriert wurde
    if(!$error) {
        $statement = $pdo->prepare("SELECT * FROM users WHERE email = :email");
        $result = $statement->execute(array('email' => $email));
        $user = $statement->fetch();

        if($user !== false) {
            echo 'Diese E-Mail-Adresse ist bereits vergeben<br>';
            $error = true;
        }
    }

    //Überprüft ob der Benutzername schon vorhanden ist
    if(!$error) {
        $statement = $pdo->prepare("SELECT * FROM users WHERE username = :username");
        $result = $statement->execute(array('username' => $username));
        $user = $statement->fetch();

        if (strlen($username) == 0) {
            echo 'Bitte einen Usernamen angeben <br>';
            $error = true;
        }
        if ($user !== false) {
            echo 'Benutzername ist zu lang oder existiert bereits <br>';
            $error = true;
        }
    if (!$error) {
        if ($sex !== "male" && $sex !== "female") {
            echo 'Please choose a sex <br>';
            $error = true;
        }
    }
    if (!$error) {
        if ($date == 0) {
            echo 'Insert your birthdate';
            $error = true;
        }
    }

    }

    //Keine Fehler, wir können den Nutzer registrieren
if(!$error) {
    $passwort_hash = password_hash($passwort, PASSWORD_DEFAULT);

    $statement = $pdo->prepare("INSERT INTO users (username, email, passwort, country, sex, date) VALUES (:username, :email, :passwort, :country, :sex, :date )");
    $result = $statement->execute(array('username' => $username, 'email' => $email, 'passwort' => $passwort_hash, 'country' => $country, 'sex' => $sex, 'date' => $date));

    $query = mysqli_query($con, "SELECT id FROM users WHERE email = '$email'");
    $row = mysqli_fetch_array($query,MYSQLI_NUM );
    $userid = $row[0];

    $statement2 = $pdo->prepare("INSERT INTO user_stat (userid, questions_answered,right_q,wrong_q,points,games_p,right_q_men,right_q_women,wrong_q_men,wrong_q_women) VALUES (:userid, :questions_answered,:right_q,:wrong_q,:points,:games_p,:right_q_men,:right_q_women,:wrong_q_men,:wrong_q_women)");
    $result2 = $statement2->execute(array('userid'=> $userid, 'questions_answered'=> 0,'right_q'=>0,'wrong_q'=>0,'points'=>0,'games_p'=>0,'right_q_men'=>0,'right_q_women'=>0,'wrong_q_men'=>0,'wrong_q_women'=>0));

    if($result) {
        echo 'Du wurdest erfolgreich registriert. <a href="login.html">Zum Login</a>';
        $showFormular = false;
    } else {
        echo 'Beim Abspeichern ist leider ein Fehler aufgetreten<br>';
    }
}


