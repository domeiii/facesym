<?php 
session_start();
require_once("inc/config.inc.php");
require_once("inc/functions.inc.php");
include("templates/header.inc.php")
?>

  

    

    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
        <h1>FaceSym</h1>
        <p>Herzlich Willkommen zu FaceSym. Logge dich ein, um loszulegen oder registriere dich!
        </p>
        <p><a class="btn btn-primary btn-lg" href="register.php" role="button">Jetzt registrieren</a></p>
      </div>
    </div>
  
<?php 
include("templates/footer.inc.php")
?>